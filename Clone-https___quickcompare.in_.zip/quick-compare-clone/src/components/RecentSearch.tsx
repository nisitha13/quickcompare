"use client";

import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

type RecentSearchProps = {
  searches: string[];
  onSelect: (search: string) => void;
};

export default function RecentSearch({ searches, onSelect }: RecentSearchProps) {
  return (
    <div className="my-4">
      <h3 className="text-xl font-semibold pb-2 border-b border-gray-200">Recent Search</h3>
      <ScrollArea className="w-full py-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          {searches.map((search) => (
            <Button
              key={search}
              variant="outline"
              className="border-gray-200 bg-white hover:bg-gray-50 rounded-full px-4 py-2 text-sm font-normal"
              onClick={() => onSelect(search)}
            >
              {search}
            </Button>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
