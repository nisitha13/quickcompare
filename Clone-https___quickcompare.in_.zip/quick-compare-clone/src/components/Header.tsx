"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ChevronDown, MapPin, Search, X } from "lucide-react";

export default function Header({
  onSearch
}: {
  onSearch?: (query: string) => void
}) {
  const [location, setLocation] = useState("Select Location");
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchActive, setIsSearchActive] = useState(false);
  const [isLocationDialogOpen, setIsLocationDialogOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch && searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  const handleClearSearch = () => {
    setSearchQuery("");
    setIsSearchActive(false);
  };

  const locations = [
    "Sector 62, Noida",
    "Sobha Classic, Haralur Main Road",
    "Tower-5, Prestige Ferns Residency",
    "Koramangala, Bangalore"
  ];

  return (
    <div className="fixed z-50 w-full max-w-[720px] mx-auto bg-white shadow rounded-b-2xl">
      <div className="flex flex-col items-center w-full">
        <div className="flex flex-col w-full py-4">
          <Dialog open={isLocationDialogOpen} onOpenChange={setIsLocationDialogOpen}>
            <DialogTrigger asChild>
              <button className="flex flex-col w-full px-4">
                <div className="flex items-center text-left text-sm text-muted-foreground">
                  Delivering to <ChevronDown className="h-4 w-4 ml-1" />
                </div>
                <div className="flex w-full items-center gap-2 text-left font-bold">
                  <div className="truncate">{location}</div>
                </div>
              </button>
            </DialogTrigger>
            <DialogContent className="max-w-[400px]">
              <DialogHeader>
                <DialogTitle>Select your delivery location</DialogTitle>
              </DialogHeader>
              <div className="flex flex-col space-y-2 max-h-[300px] overflow-y-auto">
                {locations.map((loc) => (
                  <button
                    key={loc}
                    className="flex items-center gap-2 p-3 hover:bg-muted rounded-md text-left"
                    onClick={() => {
                      setLocation(loc);
                      setIsLocationDialogOpen(false);
                    }}
                  >
                    <MapPin className="h-4 w-4 text-primary" />
                    {loc}
                  </button>
                ))}
              </div>
            </DialogContent>
          </Dialog>

          <div className="mt-2 flex w-full">
            {isSearchActive ? (
              <form className="relative w-full px-4" onSubmit={handleSearch}>
                <div className="flex items-center relative">
                  <button type="button" className="absolute left-7" onClick={() => setIsSearchActive(false)}>
                    <ChevronDown className="h-5 w-5 rotate-90 text-muted-foreground" />
                  </button>
                  <Input
                    type="search"
                    className="w-full cursor-pointer rounded-xl border border-primary pl-12 pr-10 focus:cursor-auto focus:outline-none"
                    placeholder="Search to compare prices, availability"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    autoFocus
                  />
                  {searchQuery && (
                    <button type="button" className="absolute right-7" onClick={handleClearSearch}>
                      <X className="h-5 w-5 text-muted-foreground" />
                    </button>
                  )}
                </div>
              </form>
            ) : (
              <div className="relative grow px-4">
                <button
                  className="w-full flex items-center"
                  onClick={() => setIsSearchActive(true)}
                >
                  <div className="absolute left-7">
                    <Search className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <Input
                    type="search"
                    className="w-full cursor-pointer rounded-xl border border-primary pl-12 focus:cursor-auto focus:outline-none"
                    placeholder="Search to compare prices, availability"
                    readOnly
                  />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
