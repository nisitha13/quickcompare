"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function PromoBanner() {
  return (
    <Card className="teal-gradient text-white p-6 my-4 rounded-xl overflow-hidden relative">
      <div className="flex items-center">
        <div className="flex-1 z-10">
          <h2 className="text-2xl font-bold leading-tight mb-2">
            Happiness is saving on your Groceries
          </h2>
          <Button
            className="mt-2 bg-white text-primary hover:bg-gray-100 font-semibold"
          >
            Compare & Save
          </Button>
        </div>
        <div className="w-1/2 absolute right-0 bottom-0">
          {/* Two people looking at phone, we'll represent this with a simple illustration */}
          <div className="w-full h-full flex justify-end items-end">
            <div className="relative w-full h-32">
              {/* This would ideally be an image, but we're using a placeholder */}
              <div className="absolute bottom-0 right-0 w-32 h-32 bg-yellow-400 rounded-full opacity-80" />
              <div className="absolute bottom-0 right-8 w-32 h-32 bg-yellow-400 rounded-full opacity-80" />
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
