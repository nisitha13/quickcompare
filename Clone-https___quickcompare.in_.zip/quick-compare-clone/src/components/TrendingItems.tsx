"use client";

import { Card } from "@/components/ui/card";
import Image from "next/image";

type ItemProps = {
  id: string;
  name: string;
  image: string;
};

type TrendingItemsProps = {
  items: ItemProps[];
  onSelect: (item: ItemProps) => void;
};

export default function TrendingItems({ items, onSelect }: TrendingItemsProps) {
  return (
    <div className="my-4">
      <h3 className="text-xl font-semibold pb-2 border-b border-gray-200">Trending Items</h3>
      <div className="grid grid-cols-4 gap-4 mt-4">
        {items.map((item) => (
          <div
            key={item.id}
            className="flex flex-col items-center cursor-pointer"
            onClick={() => onSelect(item)}
          >
            <Card className="w-full aspect-square overflow-hidden bg-white flex items-center justify-center p-3">
              <div className="relative w-full h-full">
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  sizes="100%"
                  style={{ objectFit: 'contain' }}
                />
              </div>
            </Card>
            <div className="text-center font-medium mt-2">{item.name}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
