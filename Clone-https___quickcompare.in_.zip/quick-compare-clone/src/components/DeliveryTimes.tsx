"use client";

import Image from "next/image";
import { Card } from "@/components/ui/card";

type Platform = {
  id: string;
  name: string;
  logo: string;
  deliveryTime: string;
  className: string;
};

export default function DeliveryTimes() {
  const platforms: Platform[] = [
    {
      id: "zepto",
      name: "zepto",
      logo: "https://ext.same-assets.com/1524299773/3783633550.svg", // This is a placeholder, replace with actual logo
      deliveryTime: "5 Mins",
      className: "platform-zepto",
    },
    {
      id: "bbnow",
      name: "bb now",
      logo: "https://ext.same-assets.com/1524299773/548389142.svg", // This is a placeholder, replace with actual logo
      deliveryTime: "35 mins",
      className: "platform-bbnow",
    },
    {
      id: "instamart",
      name: "instamart",
      logo: "https://ext.same-assets.com/1524299773/2563901416.svg", // This is a placeholder, replace with actual logo
      deliveryTime: "6 Mins",
      className: "platform-instamart",
    },
    {
      id: "blinkit",
      name: "blinkit",
      logo: "https://ext.same-assets.com/1524299773/101259959.png", // This is a placeholder, replace with actual logo
      deliveryTime: "13 Mins",
      className: "platform-blinkit",
    },
  ];

  return (
    <Card className="bg-white p-4 shadow-sm mt-4">
      <h3 className="text-lg font-medium mb-2">Delivering in</h3>
      <div className="grid grid-cols-4 gap-2">
        {platforms.map((platform) => (
          <div key={platform.id} className="flex flex-col items-center">
            <div className="text-center mb-1 text-sm">
              {platform.deliveryTime}
            </div>
            <div
              className={`flex items-center justify-center h-12 w-full rounded-md ${platform.className} p-2`}
            >
              <div className="text-center">
                {platform.id === "bbnow" ? (
                  <div className="font-bold">bb now</div>
                ) : platform.id === "zepto" ? (
                  <div className="font-bold lowercase">zepto</div>
                ) : platform.id === "blinkit" ? (
                  <div className="font-bold lowercase">blinkit</div>
                ) : (
                  <div className="font-bold flex items-center justify-center">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="mr-1">
                      <path d="M12 12C14.2091 12 16 10.2091 16 8C16 5.79086 14.2091 4 12 4C9.79086 4 8 5.79086 8 8C8 10.2091 9.79086 12 12 12Z" fill="currentColor"/>
                      <path d="M12 14C8.13401 14 5 17.134 5 21H19C19 17.134 15.866 14 12 14Z" fill="currentColor"/>
                    </svg>
                    <span>instamart</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
