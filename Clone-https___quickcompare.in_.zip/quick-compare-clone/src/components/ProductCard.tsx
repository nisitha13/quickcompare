"use client";

import { Card } from "@/components/ui/card";
import Image from "next/image";

type PlatformPrice = {
  platform: string;
  platformClass: string;
  price: number;
  mrp?: number;
  deliveryTime: string;
  quantity: string;
};

type ProductProps = {
  id: string;
  name: string;
  brand: string;
  image: string;
  platformPrices: PlatformPrice[];
};

export default function ProductCard({ product }: { product: ProductProps }) {
  return (
    <Card className="bg-white p-4 shadow-sm mb-4 overflow-hidden">
      <div className="flex items-start space-x-4 mb-3">
        <div className="w-1/3 aspect-square relative bg-white rounded-md overflow-hidden">
          <Image
            src={product.image}
            alt={product.name}
            fill
            sizes="33vw"
            style={{ objectFit: "contain" }}
          />
        </div>
        <div className="flex-1">
          <div className="text-sm text-gray-500">{product.brand}</div>
          <h3 className="font-bold text-gray-800 text-lg">{product.name}</h3>
        </div>
      </div>

      <div className="space-y-2">
        {product.platformPrices.map((platform, index) => (
          <div key={`${product.id}-${platform.platform}-${index}`} className="flex justify-between py-1 border-t border-gray-100">
            <div className={`px-3 py-1 rounded ${platform.platformClass} text-xs font-semibold w-24 flex items-center justify-center`}>
              {platform.platform}
            </div>
            <div className="text-sm">
              {platform.quantity}
            </div>
            <div className="flex items-center space-x-1">
              <div className="text-gray-400 line-through text-sm">
                {platform.mrp && `₹${platform.mrp}`}
              </div>
              <div className="font-bold text-lg">
                ₹{platform.price}
              </div>
            </div>
            <div className="text-sm text-gray-500 flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-1"
              >
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
              {platform.deliveryTime}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
