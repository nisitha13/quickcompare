"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/Header";
import DeliveryTimes from "@/components/DeliveryTimes";
import PromoBanner from "@/components/PromoBanner";
import RecentSearch from "@/components/RecentSearch";
import TrendingItems from "@/components/TrendingItems";
import WhatsAppButton from "@/components/WhatsAppButton";

// Sample data
const recentSearches = ["Rice", "Ariel", "Surf excel", "Davidoff crema"];

const trendingItems = [
  {
    id: "atta",
    name: "Atta",
    image: "https://www.bigbasket.com/media/uploads/p/l/126906_7-aashirvaad-atta-whole-wheat.jpg",
  },
  {
    id: "rice",
    name: "Rice",
    image: "https://www.bigbasket.com/media/uploads/p/l/40023008_8-daawat-basmati-rice-rozana-super.jpg",
  },
  {
    id: "detergent",
    name: "Detergent",
    image: "https://www.bigbasket.com/media/uploads/p/l/267012_9-wheel-active-green-detergent-powder.jpg",
  },
  {
    id: "coffee",
    name: "Coffee",
    image: "https://www.bigbasket.com/media/uploads/p/l/266579_12-nescafe-classic-coffee.jpg",
  },
];

export default function HomePage() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    router.push(`/search?q=${encodeURIComponent(query)}`);
  };

  const handleItemClick = (item: { id: string; name: string }) => {
    handleSearch(item.name);
  };

  return (
    <div className="flex flex-col h-full bg-background">
      <div className="fixed z-50 w-full max-w-[720px] mx-auto">
        <Header onSearch={handleSearch} />
      </div>
      <div className="pb-20 pt-32 px-4 overflow-y-auto">
        <DeliveryTimes />
        <PromoBanner />
        <RecentSearch searches={recentSearches} onSelect={handleSearch} />
        <TrendingItems items={trendingItems} onSelect={handleItemClick} />
        <WhatsAppButton />
      </div>
    </div>
  );
}
