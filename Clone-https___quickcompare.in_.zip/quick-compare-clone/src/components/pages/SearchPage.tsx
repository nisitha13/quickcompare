"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Header from "@/components/Header";
import ProductCard from "@/components/ProductCard";
import WhatsAppButton from "@/components/WhatsAppButton";
import { ArrowLeft } from "lucide-react";

type PlatformPrice = {
  platform: string;
  platformClass: string;
  price: number;
  mrp?: number;
  deliveryTime: string;
  quantity: string;
};

type Product = {
  id: string;
  name: string;
  brand: string;
  image: string;
  platformPrices: PlatformPrice[];
};

// Sample search results data
const getSampleProducts = (query: string): Product[] => {
  if (query.toLowerCase().includes('rice')) {
    return [
      {
        id: "rice1",
        name: "Daawat Rozana Super Basmati Rice (Basmati Rice)",
        brand: "Daawat",
        image: "https://www.bigbasket.com/media/uploads/p/l/40023008_8-daawat-basmati-rice-rozana-super.jpg",
        platformPrices: [
          {
            platform: "blinkit",
            platformClass: "platform-blinkit",
            price: 330,
            mrp: 495,
            deliveryTime: "14 Mins",
            quantity: "5 kg",
          },
          {
            platform: "instamart",
            platformClass: "platform-instamart",
            price: 349,
            mrp: 495,
            deliveryTime: "6 Mins",
            quantity: "5 kg",
          },
          {
            platform: "zepto",
            platformClass: "platform-zepto",
            price: 352,
            mrp: 495,
            deliveryTime: "5 Mins",
            quantity: "5 kg",
          },
        ],
      },
      {
        id: "rice2",
        name: "Daawat Basmati Rice - Rozana Super",
        brand: "Daawat",
        image: "https://www.bigbasket.com/media/uploads/p/l/40023008_8-daawat-basmati-rice-rozana-super.jpg",
        platformPrices: [
          {
            platform: "instamart",
            platformClass: "platform-instamart",
            price: 79,
            mrp: 100,
            deliveryTime: "6 Mins",
            quantity: "1 kg",
          },
          {
            platform: "blinkit",
            platformClass: "platform-blinkit",
            price: 86,
            mrp: 100,
            deliveryTime: "14 Mins",
            quantity: "1 kg",
          },
          {
            platform: "bbnow",
            platformClass: "platform-bbnow",
            price: 86.84,
            mrp: 100,
            deliveryTime: "35 mins",
            quantity: "1 kg",
          },
        ],
      },
    ];
  }

  if (query.toLowerCase().includes('surf') || query.toLowerCase().includes('detergent')) {
    return [
      {
        id: "surf1",
        name: "Surf Excel Matic Top Load Liquid Detergent Pouch",
        brand: "Surf Excel",
        image: "https://www.bigbasket.com/media/uploads/p/l/40098253_6-surf-excel-matic-top-load-liquid-detergent.jpg",
        platformPrices: [
          {
            platform: "instamart",
            platformClass: "platform-instamart",
            price: 482,
            mrp: 625,
            deliveryTime: "9 Mins",
            quantity: "3.2 L",
          },
          {
            platform: "blinkit",
            platformClass: "platform-blinkit",
            price: 525,
            mrp: 635,
            deliveryTime: "14 Mins",
            quantity: "3.2 ltr",
          },
        ],
      },
      {
        id: "surf2",
        name: "Surf Excel Liquid Detergent Matic Top Load",
        brand: "Surf Excel",
        image: "https://www.bigbasket.com/media/uploads/p/l/1214363_1-surf-excel-matic-liquid-detergent-front-load.jpg",
        platformPrices: [
          {
            platform: "instamart",
            platformClass: "platform-instamart",
            price: 377,
            mrp: 450,
            deliveryTime: "9 Mins",
            quantity: "1 L x 2",
          },
        ],
      },
    ];
  }

  return [];
};

export default function SearchPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const query = searchParams.get("q") || "";
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    if (query) {
      // In a real app, this would be an API call
      const searchResults = getSampleProducts(query);
      setProducts(searchResults);
    }
  }, [query]);

  const handleSearch = (newQuery: string) => {
    router.push(`/search?q=${encodeURIComponent(newQuery)}`);
  };

  const handleBack = () => {
    router.push("/");
  };

  return (
    <div className="flex flex-col h-full bg-background">
      <div className="fixed z-50 w-full max-w-[720px] mx-auto bg-white shadow rounded-b-2xl">
        <div className="flex items-center px-4 pt-4">
          <button
            className="flex items-center justify-center p-2 rounded-full hover:bg-gray-100"
            onClick={handleBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
        </div>
        <Header onSearch={handleSearch} />
      </div>

      <div className="pb-20 pt-40 px-4 overflow-y-auto">
        {products.length > 0 ? (
          products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))
        ) : (
          <div className="flex flex-col items-center justify-center mt-12 text-center">
            <div className="text-xl font-semibold mb-2">No results found</div>
            <div className="text-muted-foreground">
              Try searching for rice, surf, or detergent
            </div>
          </div>
        )}
      </div>
      <WhatsAppButton />
    </div>
  );
}
