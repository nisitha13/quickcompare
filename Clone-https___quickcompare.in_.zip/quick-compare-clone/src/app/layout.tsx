import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ClientBody from "./ClientBody";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Quick Compare - Compare Prices Across Quick Commerce Apps | Real-time Price Comparison",
  description: "Compare prices across Blinkit, Zepto, Swiggy, and more quick commerce apps in real-time. Save money on groceries, daily essentials, and household items.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable}`}>
      <ClientBody>
        <div className="relative mx-auto h-screen bg-background">
          <div className="relative mx-auto h-screen max-w-[720px] shadow">
            {children}
          </div>
        </div>
      </ClientBody>
    </html>
  );
}
