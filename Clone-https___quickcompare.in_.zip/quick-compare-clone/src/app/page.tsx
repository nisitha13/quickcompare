import HomePage from "@/components/pages/HomePage";

export default function Home() {
  return <HomePage />;
}
