"use client";

import { Suspense } from "react";
import SearchPage from "@/components/pages/SearchPage";

export default function Search() {
  return (
    <Suspense fallback={<div className="p-8 text-center">Loading...</div>}>
      <SearchPage />
    </Suspense>
  );
}
